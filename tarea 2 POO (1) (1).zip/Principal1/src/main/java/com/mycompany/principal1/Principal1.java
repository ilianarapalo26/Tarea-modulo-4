/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.principal1;

/**
 *
 * @author irapa
 */
public class Principal {
    public static void main(String[] args) {
        // Crear una instancia de la clase Recursos
        Recursos recursos = new Recursos();

        // Llamar al primer método y mostrar el mensaje
        String mensaje = recursos.obtenerMensaje();
        System.out.println(mensaje);

        // Llamar al segundo método con una edad de ejemplo y mostrar el resultado
        int edad = 20; // Puedes cambiar el valor para probar diferentes edades
        String resultadoEdad = recursos.verificarEdad(edad);
        System.out.println("Edad: " + edad + " - " + resultadoEdad);

        // Llamar al tercer método con dos números de ejemplo y mostrar el resultado
        int a = 7;
        int b = 3;
        int resultadoMultiplicacion = recursos.multiplicar(a, b);
        System.out.println("Multiplicación: " + a + " * " + b + " = " + resultadoMultiplicacion);

        // Llamar al cuarto método con un número de ejemplo y mostrar la lista
        int x = 10; // Puedes cambiar el valor para probar diferentes listas
        List<Integer> listaNumeros = recursos.generarLista(x);
        System.out.println("Lista del 1 al " + x + ": " + listaNumeros);
    }
}
