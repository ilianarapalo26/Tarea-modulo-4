/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.saludo;

/**
 *
 * @author irapa
 */
public class Saludo {

    public static void main(String[] args) {
       String nombre="Iliana Rapalo";
       System.out.println("Hola, soy" +nombre);
    }
}
