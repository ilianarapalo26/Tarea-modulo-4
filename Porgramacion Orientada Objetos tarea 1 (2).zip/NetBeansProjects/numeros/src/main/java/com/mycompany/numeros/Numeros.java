/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.numeros;

/**
 *
 * @author irapa
 */
public class Numeros {
    public static void main(String[] args) {
        // Usar un bucle for para imprimir los números pares del 2 al 100
        for (int i = 2; i <= 100; i += 2) {
            System.out.println(i);
        }
    }
}