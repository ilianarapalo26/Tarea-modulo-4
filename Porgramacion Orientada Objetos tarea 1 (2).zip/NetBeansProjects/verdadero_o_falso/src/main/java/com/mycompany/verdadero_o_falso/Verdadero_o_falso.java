/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.verdadero_o_falso;

/**
 *
 * @author irapa
 */

public class Verdadero_o_falso {
    public static void main(String[] args) {
        int M = 6;
        int T = 1;
        int K = -10;

        // Evaluar expresiones
        boolean expr1 = M > T;
        boolean expr2 = (T / K) == -5;
        boolean expr3 = (M + T == 7) || (M - T == 5);

        // Imprimir resultados
        System.out.println("M > T: " + expr1);
        System.out.println("T / K == -5: " + expr2);
        System.out.println("(M + T == 7) || (M - T == 5): " + expr3);
    }
}