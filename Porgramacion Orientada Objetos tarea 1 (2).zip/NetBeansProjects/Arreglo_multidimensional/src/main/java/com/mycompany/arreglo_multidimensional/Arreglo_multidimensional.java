/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arreglo_multidimensional;

/**
 *
 * @author irapa
 */
public class Arreglo_multidimensional {
    public static void main(String[] args) {
        // Crear un arreglo multidimensional para los datos personales
        String[][] datosPersonales = {
            {"Daniel", "Medina", "Electronica", "TEST"},
            {"Monica", "Jiz", "Computacion", "IMSA"},
            {"Jhony", "Amaya", "Ingenieria Civil", "ABC Constructora"},
            {"Arnol", "Gutierrez", "Medicina", "Hospital Central"},
            {"Bianca", "Bonilla", "Arquitectura", "Diseños XYZ"}
        };

        // Crear un arreglo de notas
        int[] notas = {65, 89, 72, 50, 95};

        // Definir el umbral de aprobación
        int umbralAprobacion = 60;

        // Imprimir los datos de los estudiantes junto con sus notas y estado
        for (int i = 0; i < datosPersonales.length; i++) {
            String nombre = datosPersonales[i][0];
            int nota = notas[i];
            String estado = nota >= umbralAprobacion ? "Aprobado" : "Reprobado";

            System.out.println(nombre);
            System.out.println(nota);
            System.out.println(estado);
            System.out.println(); // Línea en blanco para separar los registros
        }
    }
}
