/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arreglo;

/**
 *
 * @author irapa
 */
public class Arreglo {
    public static void main(String[] args) {
        // Crear un arreglo de nombres
        String[] nombres = {
            "Jhony Amaya",
            "Arnol Gutierrez",
            "Bianca Bonilla",
            "Carlos Quintero",
            "David Enoc",
            "Dunia Bejarano",
            "Andrea Boves",
            "Yajaira Enamorado",
            "Wilson Juarez"
        };

        // Imprimir los nombres
        for (int i = 0; i < nombres.length; i++) {
            System.out.println(nombres[i]);
        }
    }
}


